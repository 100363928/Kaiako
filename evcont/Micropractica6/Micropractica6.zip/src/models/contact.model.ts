export interface Contact{

  key: string; //maneja id cuando se usa firebase
  nombre: string;
  organizacion: string;
  movil: string;
  correo: string;

}
